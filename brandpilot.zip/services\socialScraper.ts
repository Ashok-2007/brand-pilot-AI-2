import { BrandIdentity } from "../types";
import { db } from "./db";
import { triggerN8nWorkflow } from "./n8nService";


export const scrapeSocialMetrics = async (brand: BrandIdentity) => {
  const settings = await db.getSettings();

  // --- N8N AUTOMATION PATH ---
  if (settings.enableN8n && settings.n8nWebhookUrl) {
    try {
      console.log("Using n8n Automation for scraping...");
      const result = await triggerN8nWorkflow(settings.n8nWebhookUrl, {
        task: "social_scrape",
        brandName: brand.name,
        socialUrls: brand.socialUrls,
      });
      return {
        followers: result.followers || 0,
        engagementRate: result.engagementRate || "N/A",
        topPostUrl: result.topPostUrl || "",
        lastScraped: new Date().toISOString(),
      };
    } catch (n8nError) {
      console.error("n8n automation failed:", n8nError);
      throw new Error("Live social scraping failed via n8n automation.");
    }
  }

  throw new Error("Live social scraping requires n8n automation configured in Settings.");
};
