@echo off
pushd "%~dp0"
echo [SYSTEM] Starting BrandPilot AI...
echo.

:: Verify Node
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Node.js not found.
    pause
    exit
)

:: Install check
if not exist "node_modules\sqlite3" (
    echo Installing dependencies...
    call npm install
)

:: Start Backend
start "Backend" cmd /k "npm run server"

:: Start Frontend
start "Frontend" cmd /k "npm run dev"

echo.
echo All systems launching. Browser will open in 10s...
timeout /t 10
start http://localhost:3200
exit
