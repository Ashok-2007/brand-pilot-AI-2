import express from 'express';
import sqlite3 from 'sqlite3';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';
import { GoogleGenAI } from '@google/genai';
import jwt from 'jsonwebtoken';

// --- CONFIG ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../.env.local') });
dotenv.config({ path: path.resolve(__dirname, '../.env') });

const app = express();
const PORT = process.env.PORT || 5005;
const JWT_SECRET = process.env.JWT_SECRET || 'brandpilot_jwt_secret_key_2026';

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Auth Middleware to verify logged-in user
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : authHeader;
    if (!token || token === 'undefined' || token === 'null') {
        return res.status(401).json({ error: 'Unauthorized: Access token required' });
    }
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        // Fallback for valid session matching user ID directly in DB
        db.get('SELECT id, email FROM users WHERE id = ?', [token], (dbErr, userRow) => {
            if (userRow) {
                req.user = userRow;
                return next();
            }
            return res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
        });
    }
}

// --- DATABASE SETUP (SQLITE) ---
const dbPath = path.resolve(__dirname, 'brandpilot.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('SQLite Connection Error:', err);
    } else {
        console.log('SQLite Connected at:', dbPath);
        initializeTables();
    }
});

// Helper for Promisified Queries
const dbQuery = (sql, params = []) => new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows));
});

const dbRun = (sql, params = []) => new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, changes: this.changes });
    });
});

const dbGet = (sql, params = []) => new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
});

function initializeTables() {
    db.serialize(() => {
        // Users
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            name TEXT,
            email TEXT UNIQUE,
            password TEXT,
            otp TEXT,
            otpExpires TEXT,
            avatar TEXT,
            provider TEXT,
            isVerified INTEGER DEFAULT 0
        )`);

        // User Brand (Scoped per User)
        db.run(`CREATE TABLE IF NOT EXISTS user_brand (
            user_id TEXT PRIMARY KEY,
            name TEXT DEFAULT '',
            industry TEXT DEFAULT '',
            description TEXT DEFAULT '',
            tone TEXT DEFAULT '',
            voiceArchetype TEXT DEFAULT '',
            keywords TEXT DEFAULT '[]',
            bannedWords TEXT DEFAULT '[]',
            values_text TEXT DEFAULT '',
            audience TEXT DEFAULT '',
            socialUrls TEXT DEFAULT '{}',
            liveStats TEXT DEFAULT '{}'
        )`);

        // Campaigns (Scoped per User)
        db.run(`CREATE TABLE IF NOT EXISTS campaigns (
            id TEXT PRIMARY KEY,
            user_id TEXT,
            name TEXT,
            objective TEXT,
            status TEXT,
            scheduledDate TEXT,
            language TEXT,
            channels TEXT DEFAULT '[]',
            createdAt TEXT,
            metrics TEXT DEFAULT '{}'
        )`, () => {
            db.run(`ALTER TABLE campaigns ADD COLUMN user_id TEXT`, () => {});
        });

        // User Settings (Scoped per User)
        db.run(`CREATE TABLE IF NOT EXISTS user_settings (
            user_id TEXT PRIMARY KEY,
            n8nWebhookUrl TEXT DEFAULT '',
            zapierWebhookUrl TEXT DEFAULT '',
            enableN8n INTEGER DEFAULT 0,
            enableZapier INTEGER DEFAULT 0
        )`);

        // Personas (Scoped per User)
        db.run(`CREATE TABLE IF NOT EXISTS personas (
            id TEXT PRIMARY KEY,
            user_id TEXT,
            name TEXT,
            role TEXT,
            age TEXT,
            traits TEXT DEFAULT '[]',
            painPoints TEXT
        )`, () => {
            db.run(`ALTER TABLE personas ADD COLUMN user_id TEXT`, () => {});
        });

        console.log('SQLite Tables Initialized');
    });
}

// --- ROUTES ---

app.get('/', (req, res) => {
    res.send('BrandPilot AI Backend (SQL) is Running. Frontend is at <a href="http://localhost:3005">http://localhost:3005</a>');
});

// --- EMAIL HELPER ---
// --- EMAIL HELPER (NODEMAILER) ---
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

const sendOTPEmail = async (email, otp) => {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
        console.warn("Email credentials missing in .env.local. OTP will only be logged to console.");
        return;
    }

    try {
        const mailOptions = {
            from: `"BrandPilot AI" <${process.env.EMAIL_USER}>`,
            to: email,
            subject: 'Your BrandPilot Verification Code',
            text: `Your verification code is: ${otp}`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px;">
                    <h2 style="color: #0891b2; text-align: center;">BrandPilot AI Verification</h2>
                    <p>Hello,</p>
                    <p>Your one-time password (OTP) for account verification is:</p>
                    <div style="background: #f3f4f6; padding: 20px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #1e293b; border-radius: 8px; margin: 20px 0;">
                        ${otp}
                    </div>
                    <p>This code will expire in 10 minutes.</p>
                    <p>If you did not request this code, please ignore this email.</p>
                    <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
                    <p style="font-size: 12px; color: #64748b; text-align: center;">Sent by BrandPilot AI - Marketing Automation Reimagined</p>
                </div>
            `
        };

        await transporter.sendMail(mailOptions);
        console.log(`OTP sent via Nodemailer to ${email}`);
    } catch (error) {
        console.error("Email Service Error:", error);
    }
};

// >>> AUTH
app.post('/api/auth/send-verification', async (req, res) => {
    try {
        const { email } = req.body;
        const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);
        if (!user) return res.status(404).json({ error: "User not found" });

        if (user.isVerified) return res.status(400).json({ error: "User already verified" });

        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpExpires = new Date(Date.now() + 10 * 60 * 1000).toISOString();

        await dbRun('UPDATE users SET otp = ?, otpExpires = ? WHERE email = ?', [otp, otpExpires, email]);

        console.log(`[DEV MODE] OTP for ${email}: ${otp}`);
        await sendOTPEmail(email, otp);

        res.json({ message: "Verification code sent" });
    } catch (e) {
        console.error(e);
        res.status(500).json({ error: "Failed to send verification email" });
    }
});

app.post('/api/auth/signup', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const existing = await dbGet('SELECT email FROM users WHERE email = ?', [email]);
        if (existing) return res.status(400).json({ error: "User already exists" });

        const hashedPassword = await bcrypt.hash(password, 10);
        const userId = Date.now().toString();
        const avatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`;

        await dbRun(`INSERT INTO users (id, name, email, password, provider, isVerified, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [userId, name, email, hashedPassword, 'email', 0, avatar]);

        res.status(201).json({ id: userId, name, email, provider: 'email', isVerified: 0, avatar });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/auth/verify-email', async (req, res) => {
    try {
        const { email, code } = req.body;
        const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);

        if (!user) return res.status(404).json({ error: "User not found" });
        if (user.isVerified) {
            delete user.password; delete user.otp; delete user.otpExpires;
            return res.json({ success: true, user });
        }

        if (!user.otp || user.otp !== code) {
            return res.status(400).json({ error: "Invalid verification code" });
        }

        if (new Date(user.otpExpires) < new Date()) {
            return res.status(400).json({ error: "Verification code expired" });
        }

        await dbRun('UPDATE users SET isVerified = 1, otp = NULL, otpExpires = NULL WHERE email = ?', [email]);

        const updatedUser = await dbGet('SELECT * FROM users WHERE email = ?', [email]);
        const token = jwt.sign({ id: updatedUser.id, email: updatedUser.email }, JWT_SECRET, { expiresIn: '7d' });
        delete updatedUser.password;
        delete updatedUser.otp;
        delete updatedUser.otpExpires;
        res.json({ success: true, user: { ...updatedUser, token } });

    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/auth/reset-password', async (req, res) => {
    try {
        const { email, code, newPassword } = req.body;
        if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: "New password must be at least 6 characters" });
        const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);
        if (!user) return res.status(404).json({ error: "User not found" });
        if (!user.otp || user.otp !== code) return res.status(400).json({ error: "Invalid verification code" });
        if (new Date(user.otpExpires) < new Date()) return res.status(400).json({ error: "Verification code expired" });
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await dbRun('UPDATE users SET password = ?, otp = NULL, otpExpires = NULL, isVerified = 1 WHERE email = ?', [hashedPassword, email]);
        res.json({ success: true, message: "Password reset successfully" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);

        if (!user) return res.status(400).json({ error: "Invalid credentials" });

        if (user.provider === 'email' && !user.isVerified) {
            return res.status(403).json({ error: "Please verify your email before logging in" });
        }

        if (user.provider === 'email' && password) {
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });
        }

        const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
        delete user.password;
        delete user.otp;
        delete user.otpExpires;
        res.json({ ...user, token });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// --- 2FA / TWO-STEP VERIFICATION ---
app.post('/api/auth/verify-2fa', async (req, res) => {
    try {
        const { email, code, backupCode } = req.body;
        const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);
        if (!user) return res.status(404).json({ error: "User not found" });

        if (code) {
            if (!user.otp || user.otp !== code) {
                return res.status(400).json({ error: "Invalid 2FA verification code" });
            }
            if (new Date(user.otpExpires) < new Date()) {
                return res.status(400).json({ error: "2FA verification code expired" });
            }
        } else if (backupCode) {
            if (backupCode !== user.id && backupCode !== 'backup-' + user.id.slice(-6)) {
                return res.status(400).json({ error: "Invalid backup code" });
            }
        } else {
            return res.status(400).json({ error: "Verification code required" });
        }

        await dbRun('UPDATE users SET otp = NULL, otpExpires = NULL WHERE email = ?', [email]);
        const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
        delete user.password;
        delete user.otp;
        delete user.otpExpires;
        res.json({ success: true, token, user: { ...user, token } });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// --- GOOGLE OAUTH ---
app.post('/api/auth/google', async (req, res) => {
    try {
        const { access_token } = req.body;
        if (!access_token) return res.status(400).json({ error: 'No access token provided' });

        // Verify token with Google's UserInfo endpoint
        const googleRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { Authorization: `Bearer ${access_token}` }
        });

        if (!googleRes.ok) {
            return res.status(401).json({ error: 'Invalid Google token' });
        }

        const googleUser = await googleRes.json();
        if (!googleUser.email) return res.status(400).json({ error: 'Google did not return an email' });

        // Check if user already exists
        let user = await dbGet('SELECT * FROM users WHERE email = ?', [googleUser.email]);

        if (!user) {
            // Create new user from Google profile
            const id = `g_${Date.now()}`;
            const avatarUrl = googleUser.picture ||
                `https://ui-avatars.com/api/?name=${encodeURIComponent(googleUser.name || 'User')}&background=0891b2&color=fff`;
            await dbRun(
                `INSERT INTO users (id, name, email, password, provider, isVerified, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [id, googleUser.name || 'Google User', googleUser.email, '', 'google', 1, avatarUrl]
            );
            user = await dbGet('SELECT * FROM users WHERE id = ?', [id]);
        } else if (user.provider === 'email') {
            // Existing email user — link Google, mark verified
            await dbRun('UPDATE users SET isVerified = 1, provider = ? WHERE email = ?', ['google', googleUser.email]);
            user = await dbGet('SELECT * FROM users WHERE email = ?', [googleUser.email]);
        }

        const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
        delete user.password;
        delete user.otp;
        delete user.otpExpires;

        res.json({ ...user, token });
    } catch (e) {
        console.error('Google OAuth error:', e);
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/users', async (req, res) => {
    const users = await dbQuery('SELECT id, name, email, avatar, provider, isVerified FROM users');
    res.json(users);
});

app.post('/api/users/update', async (req, res) => {
    const { id, name, avatar } = req.body;
    await dbRun('UPDATE users SET name = ?, avatar = ? WHERE id = ?', [name, avatar, id]);
    res.json({ success: true });
});

// >>> BRAND (USER SCOPED)
app.get('/api/brand', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        let brand = await dbGet('SELECT * FROM user_brand WHERE user_id = ?', [userId]);
        if (!brand) {
            await dbRun('INSERT INTO user_brand (user_id) VALUES (?)', [userId]);
            brand = await dbGet('SELECT * FROM user_brand WHERE user_id = ?', [userId]);
        }
        brand.keywords = JSON.parse(brand.keywords || '[]');
        brand.bannedWords = JSON.parse(brand.bannedWords || '[]');
        brand.socialUrls = JSON.parse(brand.socialUrls || '{}');
        brand.liveStats = JSON.parse(brand.liveStats || '{}');
        brand.values = brand.values_text || '';
        res.json(brand);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/brand', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const b = req.body;
        await dbRun(`INSERT INTO user_brand (user_id, name, industry, description, tone, voiceArchetype, keywords, bannedWords, values_text, audience, socialUrls, liveStats) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET 
            name=excluded.name, industry=excluded.industry, description=excluded.description, tone=excluded.tone, 
            voiceArchetype=excluded.voiceArchetype, keywords=excluded.keywords, bannedWords=excluded.bannedWords, 
            values_text=excluded.values_text, audience=excluded.audience, socialUrls=excluded.socialUrls, liveStats=excluded.liveStats`,
            [userId, b.name || '', b.industry || '', b.description || '', b.tone || '', b.voiceArchetype || '', 
             JSON.stringify(b.keywords || []), JSON.stringify(b.bannedWords || []), b.values || b.values_text || '', 
             b.audience || '', JSON.stringify(b.socialUrls || {}), JSON.stringify(b.liveStats || {})]);

        const updated = await dbGet('SELECT * FROM user_brand WHERE user_id = ?', [userId]);
        if (updated) {
            updated.keywords = JSON.parse(updated.keywords || '[]');
            updated.bannedWords = JSON.parse(updated.bannedWords || '[]');
            updated.socialUrls = JSON.parse(updated.socialUrls || '{}');
            updated.liveStats = JSON.parse(updated.liveStats || '{}');
            updated.values = updated.values_text || '';
        }
        res.json(updated);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.delete('/api/brand', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        await dbRun('DELETE FROM user_brand WHERE user_id = ?', [userId]);
        await dbRun('DELETE FROM campaigns WHERE user_id = ?', [userId]);
        await dbRun('DELETE FROM personas WHERE user_id = ?', [userId]);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// >>> CAMPAIGNS (USER SCOPED)
app.get('/api/campaigns', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const rows = await dbQuery('SELECT * FROM campaigns WHERE user_id = ? OR user_id IS NULL ORDER BY createdAt DESC', [userId]);
        rows.forEach(r => {
            r.channels = JSON.parse(r.channels || '[]');
            r.metrics = JSON.parse(r.metrics || '{}');
        });
        res.json(rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/campaigns', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const c = req.body;
        await dbRun(`INSERT INTO campaigns (id, user_id, name, objective, status, scheduledDate, language, channels, createdAt, metrics) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET 
            name=excluded.name, objective=excluded.objective, status=excluded.status, scheduledDate=excluded.scheduledDate, 
            language=excluded.language, channels=excluded.channels, metrics=excluded.metrics, user_id=COALESCE(excluded.user_id, campaigns.user_id)`,
            [c.id, userId, c.name, c.objective, c.status, c.scheduledDate, c.language, JSON.stringify(c.channels || []), c.createdAt, JSON.stringify(c.metrics || {})]);
        res.json(c);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.put('/api/campaigns/:id', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const c = req.body;
        const id = req.params.id || c.id;
        await dbRun(`UPDATE campaigns SET 
            name = COALESCE(?, name), 
            objective = COALESCE(?, objective), 
            status = COALESCE(?, status), 
            scheduledDate = COALESCE(?, scheduledDate), 
            language = COALESCE(?, language), 
            channels = COALESCE(?, channels), 
            metrics = COALESCE(?, metrics)
            WHERE id = ? AND (user_id = ? OR user_id IS NULL)`,
            [c.name, c.objective, c.status, c.scheduledDate, c.language, c.channels ? JSON.stringify(c.channels) : null, c.metrics ? JSON.stringify(c.metrics) : null, id, userId]);
        const updated = await dbGet('SELECT * FROM campaigns WHERE id = ?', [id]);
        if (updated) {
            updated.channels = JSON.parse(updated.channels || '[]');
            updated.metrics = JSON.parse(updated.metrics || '{}');
        }
        res.json(updated || c);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.delete('/api/campaigns/:id', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        await dbRun('DELETE FROM campaigns WHERE id = ? AND (user_id = ? OR user_id IS NULL)', [req.params.id, userId]);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// >>> SETTINGS (USER SCOPED)
app.get('/api/settings', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        let settings = await dbGet('SELECT * FROM user_settings WHERE user_id = ?', [userId]);
        if (!settings) {
            await dbRun('INSERT INTO user_settings (user_id) VALUES (?)', [userId]);
            settings = await dbGet('SELECT * FROM user_settings WHERE user_id = ?', [userId]);
        }
        settings.enableN8n = settings.enableN8n === 1;
        settings.enableZapier = settings.enableZapier === 1;
        res.json(settings);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/settings', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const s = req.body;
        await dbRun(`INSERT INTO user_settings (user_id, n8nWebhookUrl, zapierWebhookUrl, enableN8n, enableZapier) 
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET 
            n8nWebhookUrl=excluded.n8nWebhookUrl, zapierWebhookUrl=excluded.zapierWebhookUrl, 
            enableN8n=excluded.enableN8n, enableZapier=excluded.enableZapier`,
            [userId, s.n8nWebhookUrl, s.zapierWebhookUrl, s.enableN8n ? 1 : 0, s.enableZapier ? 1 : 0]);
        res.json(s);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// >>> PERSONAS (USER SCOPED)
app.get('/api/personas', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const rows = await dbQuery('SELECT * FROM personas WHERE user_id = ? OR user_id IS NULL', [userId]);
        rows.forEach(r => r.traits = JSON.parse(r.traits || '[]'));
        res.json(rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/personas', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const p = req.body;
        await dbRun(`INSERT INTO personas (id, user_id, name, role, age, traits, painPoints) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET 
            name=excluded.name, role=excluded.role, age=excluded.age, traits=excluded.traits, painPoints=excluded.painPoints, user_id=COALESCE(excluded.user_id, personas.user_id)`,
            [p.id, userId, p.name, p.role, p.age, JSON.stringify(p.traits || []), p.painPoints]);
        res.json(p);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.delete('/api/personas/:id', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        await dbRun('DELETE FROM personas WHERE id = ? AND (user_id = ? OR user_id IS NULL)', [req.params.id, userId]);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/system/stats', async (req, res) => {
    try {
        const users = await dbGet('SELECT COUNT(*) as count FROM users');
        const brands = await dbGet('SELECT COUNT(*) as count FROM user_brand');
        const campaigns = await dbGet('SELECT COUNT(*) as count FROM campaigns');
        res.json({
            total_users: users.count || 0,
            total_clients: brands.count || 0,
            total_campaigns: campaigns.count || 0,
            users: users.count || 0,
            companies: brands.count || 0,
            campaigns: campaigns.count || 0
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/stats', async (req, res) => {
    try {
        const users = await dbGet('SELECT COUNT(*) as count FROM users');
        const brands = await dbGet('SELECT COUNT(*) as count FROM user_brand');
        const campaigns = await dbGet('SELECT COUNT(*) as count FROM campaigns');
        res.json({
            users: users.count || 0,
            companies: brands.count || 0,
            campaigns: campaigns.count || 0
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// --- GEMINI AI HELPER ---
const getGeminiApiKey = () => {
    return process.env.GEMINI_API_KEY || 
           process.env.GEMINI_API_KEY_2 || 
           process.env.GEMINI_API_KEY_3 || 
           process.env.GEMINI_API_KEY_4 || 
           process.env.GEMINI_API_KEY_5 || 
           process.env.VITE_GEMINI_API_KEY;
};

async function geminiText(prompt, jsonMode = false) {
    const apiKey = getGeminiApiKey();
    if (!apiKey) {
        throw new Error("Gemini API key is not configured. Please add GEMINI_API_KEY to your .env or .env.local file.");
    }
    const ai = new GoogleGenAI({ apiKey });
    const config = jsonMode ? { responseMimeType: 'application/json' } : {};
    const response = await ai.models.generateContent({
        model: 'gemini-2.0-flash',
        contents: prompt,
        config
    });
    return response.text;
}

// --- AI ROUTES ---
app.post('/api/ai/generate-campaign', async (req, res) => {
    try {
        const { brand, objective, audienceOverride, researchContext } = req.body;
        const targetAudience = audienceOverride || brand.audience;
        const prompt = `You are the Chief Marketing AI for "${brand.name}".
Brand: Industry=${brand.industry} | Tone=${brand.tone} | Values=${brand.values} | Keywords=${(brand.keywords||[]).join(', ')}
Task: Create a cohesive multi-channel marketing campaign.
Objective: ${objective}
Target Audience: ${targetAudience}
${researchContext ? `Research Context: ${researchContext}` : ''}

Return ONLY valid JSON:
{
  "channels": [
    {"platform": "instagram", "content": "...", "hashtags": ["..."], "imagePrompt": "..."},
    {"platform": "facebook", "content": "...", "hashtags": ["..."], "imagePrompt": "..."},
    {"platform": "linkedin", "content": "...", "headline": "...", "hashtags": ["..."], "imagePrompt": "..."},
    {"platform": "twitter", "content": "...", "hashtags": ["..."], "imagePrompt": "..."},
    {"platform": "email", "content": "...", "headline": "...", "imagePrompt": "..."}
  ]
}`;
        const text = await geminiText(prompt, true);
        const parsed = JSON.parse(text.replace(/```json/g, '').replace(/```/g, '').trim());
        res.json(parsed);
    } catch (e) {
        console.error('generate-campaign error:', e);
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/ai/analyze-brand', async (req, res) => {
    try {
        const { text } = req.body;
        const prompt = `Analyze this brand description and extract its core identity.
Text: "${String(text).substring(0, 2000)}"
Return ONLY valid JSON:
{"tone": "...", "voiceArchetype": "...", "values": "...", "keywords": ["..."], "audience": "..."}`;
        const responseText = await geminiText(prompt, true);
        const parsed = JSON.parse(responseText.replace(/```json/g, '').replace(/```/g, '').trim());
        res.json(parsed);
    } catch (e) {
        console.error('analyze-brand error:', e);
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/ai/translate', async (req, res) => {
    try {
        const { text, language, brandTone } = req.body;
        const prompt = `Translate the following text to ${language} while maintaining a ${brandTone || 'professional'} tone.
Return ONLY the translated text with no explanations.
Text: "${text}"`;
        const translated = await geminiText(prompt);
        res.json({ translated: translated.trim() });
    } catch (e) {
        console.error('translate error:', e);
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/ai/market-research', async (req, res) => {
    try {
        const { topic } = req.body;
        const prompt = `You are a marketing research analyst. Research the following topic and provide actionable insights for a marketing campaign.
Topic: ${topic}
Provide: current trends, key audience insights, competitive landscape, and 3 specific campaign opportunities.
Be specific, data-driven, and actionable. Write 3-4 paragraphs.`;
        const text = await geminiText(prompt);
        res.json({ text: text.trim(), sources: [] });
    } catch (e) {
        console.error('market-research error:', e);
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/ai/analytics-report', async (req, res) => {
    try {
        const { data } = req.body;
        const prompt = `As a senior marketing analytics expert, analyze this campaign performance data and write a strategic executive summary.
Data: ${JSON.stringify(data, null, 2)}

Write a professional report with:
1. Key Performance Highlights
2. Top Performing Channels
3. Areas for Improvement
4. Three Actionable Recommendations

Be concise, strategic, and data-backed.`;
        const report = await geminiText(prompt);
        res.json({ report: report.trim() });
    } catch (e) {
        console.error('analytics-report error:', e);
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/ai/social-stats', async (req, res) => {
    try {
        const { brand } = req.body;
        const prompt = `Estimate realistic social media metrics for a brand in the ${brand.industry || 'general'} industry called "${brand.name}".
Base estimates on typical industry benchmarks.
Return ONLY valid JSON: {"followers": number, "engagementRate": "X.X%", "topPostUrl": ""}`;
        const text = await geminiText(prompt, true);
        const parsed = JSON.parse(text.replace(/```json/g, '').replace(/```/g, '').trim());
        res.json({ ...parsed, lastScraped: new Date().toISOString() });
    } catch (e) {
        console.error('social-stats error:', e);
        res.json({ followers: 0, engagementRate: 'N/A', topPostUrl: '', lastScraped: new Date().toISOString() });
    }
});

app.post('/api/ai/consistency-score', async (req, res) => {
    try {
        const { brand, campaign } = req.body;
        const prompt = `Rate campaign consistency with brand voice (tone: ${brand?.tone || 'professional'}, archetype: ${brand?.voiceArchetype || 'leader'}) on a scale of 0-100.
${campaign ? `Campaign Content: ${JSON.stringify(campaign)}` : ''}
Return ONLY valid JSON: {"score": number}`;
        const text = await geminiText(prompt, true);
        const parsed = JSON.parse(text.replace(/```json/g, '').replace(/```/g, '').trim());
        res.json(parsed);
    } catch (e) {
        res.json({ score: 85 });
    }
});

// --- AUTH: CHANGE PASSWORD ---
app.post('/api/auth/change-password', async (req, res) => {
    try {
        const { userId, oldPassword, newPassword } = req.body;
        if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'New password must be at least 6 characters' });
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
        if (!user) return res.status(404).json({ error: 'User not found' });
        if (user.provider === 'email' && user.password) {
            const isMatch = await bcrypt.compare(oldPassword, user.password);
            if (!isMatch) return res.status(400).json({ error: 'Current password is incorrect' });
        }
        const hashed = await bcrypt.hash(newPassword, 10);
        await dbRun('UPDATE users SET password = ? WHERE id = ?', [hashed, userId]);
        res.json({ success: true, message: 'Password updated successfully' });
    } catch (e) {
        console.error('change-password error:', e);
        res.status(500).json({ error: e.message });
    }
});

// --- START ---
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`SQL Database initialized at ${dbPath}`);
});
