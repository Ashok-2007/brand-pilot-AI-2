
import React, { createContext, useState, useEffect } from 'react';
import { BrandIdentity, MultiChannelCampaign, AppSettings, Persona, BrandContextType } from '../types';
import { db } from '../services/db';

export const BrandContext = createContext<BrandContextType>({} as BrandContextType);

export const BrandProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [brand, setBrand] = useState<BrandIdentity>({
        name: "", industry: "", description: "", tone: "", voiceArchetype: "",
        keywords: [], bannedWords: [], values: "", audience: "", socialUrls: {}
    });

    const [settings, setSettings] = useState<AppSettings>({
        n8nWebhookUrl: "", zapierWebhookUrl: "", enableN8n: false, enableZapier: false
    });

    const [personas, setPersonas] = useState<Persona[]>([]);
    const [campaigns, setCampaigns] = useState<MultiChannelCampaign[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [b, s, p, c] = await Promise.all([
                    db.getBrand().catch(() => brand),
                    db.getSettings().catch(() => settings),
                    db.getPersonas().catch(() => []),
                    db.getCampaigns().catch(() => [])
                ]);
                if (b) setBrand(b);
                if (s) setSettings(s);
                // Ensure array fallback
                setPersonas(Array.isArray(p) ? p : []);
                setCampaigns(Array.isArray(c) ? c : []);
            } catch (error) {
                console.error("Failed to load data from backend:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const updateBrand = async (newBrand: BrandIdentity) => {
        setBrand(newBrand);
        await db.saveBrand(newBrand);
    };

    const addCampaign = async (newCampaign: MultiChannelCampaign) => {
        const updated = [newCampaign, ...campaigns];
        setCampaigns(updated);
        await db.saveCampaign(newCampaign);
    };

    const updateCampaign = async (updatedCampaign: MultiChannelCampaign) => {
        const updatedList = campaigns.map(c => c.id === updatedCampaign.id ? updatedCampaign : c);
        setCampaigns(updatedList);
        await db.updateCampaign(updatedCampaign);
    };

    const updateSettings = async (newSettings: AppSettings) => {
        setSettings(newSettings);
        await db.saveSettings(newSettings);
    };

    const addPersona = async (p: Persona) => {
        const updated = [...personas, p];
        setPersonas(updated);
        await db.savePersona(p);
    };

    const removePersona = async (id: string) => {
        const updated = personas.filter(p => p.id !== id);
        setPersonas(updated);
        await db.removePersona(id);
    };

    return (
        <BrandContext.Provider value={{
            brand, updateBrand,
            campaigns, addCampaign, updateCampaign,
            settings, updateSettings,
            personas, addPersona, removePersona
        }}>
            {children}
        </BrandContext.Provider>
    );
};
